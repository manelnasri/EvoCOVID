# Difficultés rencontrées 

Les principales difficultés rencontrées durant ce projet sont :

* La principale difficulté rencontrée durant ce projet est liée au contexte sanitaire actuel (COVID19). Il s'agit principalement d'un problème d'organisation de mon temps entre mes projets académiques et mes responsabilités en tant que maman car j'ai deux enfants en bas age à charge. 

* Mise en place du modèle MVC avec JavaFX. En début du projet, j'ai eu du mal à trouver comment appliquer le modèle MVC. Après avoir effectué des recherches, j'ai compris qu'il faut séparer les trois composantes (vue, modèle et controlleur) au niveau du code (un package dédié à chaque partie du modèle MVC. 

* J'ai eu un souci avec les composants graphiques de JavaFX (principalement les `charts`). Les TPs effectués dans le cadre de mon cours de Programmation Objet Aancée m'ont beaucoup aidé pour résoudre ces problèmees techniques. 

